#include "miniproject.h"

#define R 1
#define P 0.01



double PID_controller(double y);
